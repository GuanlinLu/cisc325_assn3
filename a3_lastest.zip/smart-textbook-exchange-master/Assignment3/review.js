window.onclick=function getMsg(){
	var display_area_Id = document.getElementById("set_Id");
	var display_area_year = document.getElementById("set_year");
	var display_area_review = document.getElementById("set_review");
	
	var btn = document.getElementById("get_button");
	
	btn.onclick=function(){
		var Id =document.getElementById("get_Id").value;
		var review = document.getElementById("get_review").value;
		var year = document.getElementById("get_year").value;
		
		display_area_Id.append(Id);
		display_area_year.append(year);
		display_area_review.append(review);
	}
}