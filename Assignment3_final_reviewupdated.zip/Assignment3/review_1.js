window.onload=function getMsg(){
    var display_area = document.getElementById("review_contanier");
    var display_area_Id=this.document.getElementById("Id_container");

    //
    var btn = document.getElementById("get_btn");
    //
    btn.onclick =function(){
        var msg = document.getElementById("get_msg").value;
        var Id = document.getElementById("get_Id").value;

        display_area.append(msg);
        display_area_Id.append(Id);

    };
    

}

